#pragma once

#define STRING_XOR_KEY 0x6F

// Hmu on discord (Chase.#1803) if you need any help :)
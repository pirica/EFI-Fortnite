# fortnite-external-efi-drivers
fortnite cheat external that uses efi drivers and is updated

ALL CREDITS TO CHASE: https://github.com/Chase1803

i just updated his src
should be pretty ud and u can prob last a few days
sell = gay
load the driver by booting it from a usb stick
if u cant figure it out then dont paste this u skid

if it says //updated then that means i updated the outdated offset 
im saying that bc skids gonna flood my dms thinking that its the only updated offsets
